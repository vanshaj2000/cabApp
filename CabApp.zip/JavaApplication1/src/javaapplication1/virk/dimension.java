package javaapplication1.virk;
public class dimension
{public void display1()
{System.out.println("this is three dimensional");
    }

}