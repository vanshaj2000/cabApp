package javaapplication1.virk1;
import java.util.*;
public class beta
{public void display()
{System.out.println("this is from beta class");
        }
}